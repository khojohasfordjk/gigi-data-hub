import express from 'express';import Database from 'better-sqlite3';import crypto from 'crypto';
const E=process.env,PORT=E.PORT||3000,BASE=E.BASE_URL||`http://localhost:${PORT}`,PSK=E.PAYSTACK_SECRET_KEY,SEC=E.SESSION_SECRET||'dev-secret';
const db=new Database('data.db');db.pragma('journal_mode=WAL');
db.exec(`CREATE TABLE IF NOT EXISTS bundles(id INTEGER PRIMARY KEY,name TEXT,size TEXT,price REAL,validity TEXT,network TEXT DEFAULT 'Gigi',active INT DEFAULT 1,demo INT DEFAULT 1);
CREATE TABLE IF NOT EXISTS ussd(id INTEGER PRIMARY KEY,service TEXT,code TEXT,description TEXT,verified INT DEFAULT 0);
CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY,ref TEXT UNIQUE,phone TEXT,email TEXT,bundle_id INT,bundle_name TEXT,amount REAL,status TEXT DEFAULT 'Pending',fulfillment TEXT DEFAULT 'Not started',created TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS tickets(id INTEGER PRIMARY KEY,name TEXT,phone TEXT,message TEXT,created TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS settings(k TEXT PRIMARY KEY,v TEXT);`);
if(!db.prepare('SELECT 1 FROM bundles').get()){const i=db.prepare('INSERT INTO bundles(name,size,price,validity) VALUES(?,?,?,?)');
[['1 GB','1 GB',5,'7 days'],['2 GB','2 GB',10,'14 days'],['5 GB','5 GB',20,'30 days'],['10 GB','10 GB',40,'30 days']].forEach(b=>i.run(...b));
db.prepare('INSERT INTO ussd(service,code,description,verified) VALUES(?,?,?,0)').run('Check balance (PLACEHOLDER)','*000#','Placeholder only. Replace with a verified Gigi code.');
db.prepare("INSERT INTO settings VALUES('banner','Demo offer: placeholder promotion text')").run();}
const app=express();
app.use((q,r,n)=>{r.set({'X-Content-Type-Options':'nosniff','X-Frame-Options':'DENY','Referrer-Policy':'same-origin'});n()});
const hmac=(s,k=SEC,a='sha256')=>crypto.createHmac(a,k).update(s).digest('hex');
const ok=(a,b)=>{a=Buffer.from(a);b=Buffer.from(b);return a.length===b.length&&crypto.timingSafeEqual(a,b)};
const ps=(path,opt={})=>fetch('https://api.paystack.co'+path,{...opt,headers:{Authorization:'Bearer '+PSK,'Content-Type':'application/json'}}).then(r=>r.json());
async function settle(ref){ // server-side verification only
 const o=db.prepare('SELECT * FROM orders WHERE ref=?').get(ref);if(!o||o.status==='Successful')return o;
 const v=await ps('/transaction/verify/'+encodeURIComponent(ref));const d=v.data;
 if(v.status&&d){const st=d.status==='success'&&d.amount===Math.round(o.amount*100)&&d.currency==='GHS'?'Successful':d.status==='failed'||d.status==='abandoned'?'Failed':'Pending';
  db.prepare('UPDATE orders SET status=?,fulfillment=? WHERE ref=?').run(st,st==='Successful'?'Awaiting fulfillment':o.fulfillment,ref);
  if(st==='Successful')deliver(o).catch(()=>{});}
 return db.prepare('SELECT * FROM orders WHERE ref=?').get(ref)}
async function deliver(o){ // Plug in an AUTHORIZED reseller API here. Only mark Delivered after it confirms.
 if(!E.DELIVERY_API_URL)return; /* TODO: call provider, then UPDATE orders SET fulfillment='Delivered' */}
app.post('/api/paystack/webhook',express.raw({type:'*/*'}),async(q,r)=>{
 if(!PSK||!ok(hmac(q.body,PSK,'sha512'),String(q.headers['x-paystack-signature']||'')))return r.sendStatus(401);
 try{const e=JSON.parse(q.body);if(e.event==='charge.success')await settle(e.data.reference)}catch{}r.sendStatus(200)});
app.use(express.json({limit:'20kb'}));
const phoneOk=p=>{p=String(p||'').replace(/[\s-]/g,'').replace(/^\+?233/,'0');return /^0\d{9}$/.test(p)?p:null};
app.get('/api/bundles',(q,r)=>r.json(db.prepare('SELECT * FROM bundles WHERE active=1 ORDER BY price').all()));
app.get('/api/ussd',(q,r)=>r.json(db.prepare('SELECT * FROM ussd').all()));
app.get('/api/config',(q,r)=>r.json({banner:db.prepare("SELECT v FROM settings WHERE k='banner'").get()?.v||'',whatsapp:E.WHATSAPP_NUMBER||'',email:E.SUPPORT_EMAIL||'',payments:!!PSK}));
app.post('/api/checkout',async(q,r)=>{
 const p=phoneOk(q.body.phone),b=db.prepare('SELECT * FROM bundles WHERE id=? AND active=1').get(+q.body.bundleId),em=String(q.body.email||'').trim();
 if(!p)return r.status(400).json({error:'Enter a valid Ghana phone number, e.g. 0241234567'});
 if(!b)return r.status(400).json({error:'Bundle not available'});
 if(!/^\S+@\S+\.\S+$/.test(em))return r.status(400).json({error:'Enter a valid email for your receipt'});
 if(!PSK)return r.status(503).json({error:'Payments are not configured yet (demo mode). No order was created.'});
 const ref='GDH'+Date.now().toString(36).toUpperCase()+crypto.randomBytes(2).toString('hex').toUpperCase();
 db.prepare('INSERT INTO orders(ref,phone,email,bundle_id,bundle_name,amount) VALUES(?,?,?,?,?,?)').run(ref,p,em,b.id,b.name+' ('+b.validity+')',b.price);
 const x=await ps('/transaction/initialize',{method:'POST',body:JSON.stringify({email:em,amount:Math.round(b.price*100),currency:'GHS',reference:ref,callback_url:BASE+'/pay/callback',channels:['mobile_money','card'],metadata:{phone:p}})});
 if(!x.status){db.prepare("UPDATE orders SET status='Failed' WHERE ref=?").run(ref);return r.status(502).json({error:'Could not start payment. Try again.'})}
 r.json({url:x.data.authorization_url,ref})});
app.get('/pay/callback',async(q,r)=>{const ref=String(q.query.reference||'');let o;try{o=await settle(ref)}catch{}r.redirect('/?track='+encodeURIComponent(ref)+(o?'&phone='+o.phone:''))});
app.get('/api/track',(q,r)=>{const o=db.prepare('SELECT ref,phone,bundle_name,amount,status,fulfillment,created FROM orders WHERE ref=? AND phone=?').get(String(q.query.ref||'').trim().toUpperCase(),phoneOk(q.query.phone)||'');
 o?r.json(o):r.status(404).json({error:'No order found for that reference and phone number'})});
app.post('/api/support',(q,r)=>{const{name,phone,message}=q.body;if(!name||!message||String(message).length>1000)return r.status(400).json({error:'Name and message are required'});
 db.prepare('INSERT INTO tickets(name,phone,message) VALUES(?,?,?)').run(String(name).slice(0,80),String(phone||'').slice(0,20),String(message));r.json({ok:1})});
// ---- Admin ----
const tries={};
app.post('/api/admin/login',(q,r)=>{const ip=q.ip,t=tries[ip]=(tries[ip]||[]).filter(x=>Date.now()-x<9e5);
 if(t.length>=8)return r.status(429).json({error:'Too many attempts'});t.push(Date.now());
 if(!E.ADMIN_PASSWORD||!ok(hmac(String(q.body.password||'')),hmac(E.ADMIN_PASSWORD)))return r.status(401).json({error:'Wrong password'});
 const exp=Date.now()+864e5;r.cookie?0:0;r.set('Set-Cookie',`adm=${exp}.${hmac('admin'+exp)}; HttpOnly; SameSite=Strict; Path=/; Max-Age=86400${BASE.startsWith('https')?'; Secure':''}`);r.json({ok:1})});
const auth=(q,r,n)=>{const c=(q.headers.cookie||'').match(/adm=(\d+)\.([a-f0-9]+)/);
 if(c&&+c[1]>Date.now()&&ok(c[2],hmac('admin'+c[1])))return n();r.status(401).json({error:'Unauthorized'})};
const A=express.Router();A.use(auth);app.use('/api/admin',A);
const crud=(t,f)=>{A.get('/'+t,(q,r)=>r.json(db.prepare(`SELECT * FROM ${t} ORDER BY id DESC`).all()));
 A.post('/'+t,(q,r)=>{const v=f.map(k=>q.body[k]??null);r.json({id:db.prepare(`INSERT INTO ${t}(${f}) VALUES(${f.map(()=>'?')})`).run(...v).lastInsertRowid})});
 A.put('/'+t+'/:id',(q,r)=>{db.prepare(`UPDATE ${t} SET ${f.map(k=>k+'=?')} WHERE id=?`).run(...f.map(k=>q.body[k]??null),+q.params.id);r.json({ok:1})});
 A.delete('/'+t+'/:id',(q,r)=>{db.prepare(`DELETE FROM ${t} WHERE id=?`).run(+q.params.id);r.json({ok:1})})};
crud('bundles',['name','size','price','validity','network','active','demo']);crud('ussd',['service','code','description','verified']);
A.get('/orders',(q,r)=>{const s='%'+(q.query.q||'')+'%';r.json(db.prepare('SELECT * FROM orders WHERE ref LIKE ? OR phone LIKE ? OR status LIKE ? ORDER BY id DESC LIMIT 200').all(s,s,s))});
A.put('/orders/:id/fulfillment',(q,r)=>{const f=['Awaiting fulfillment','Delivered','Failed'];if(!f.includes(q.body.fulfillment))return r.sendStatus(400);
 db.prepare("UPDATE orders SET fulfillment=? WHERE id=? AND status='Successful'").run(q.body.fulfillment,+q.params.id);r.json({ok:1})});
A.post('/orders/:ref/refund',(q,r)=>{db.prepare("UPDATE orders SET status='Refunded' WHERE ref=? AND status='Successful'").run(q.params.ref);r.json({ok:1})}); // mark after refunding in Paystack dashboard
A.get('/tickets',(q,r)=>r.json(db.prepare('SELECT * FROM tickets ORDER BY id DESC').all()));
A.get('/stats',(q,r)=>r.json(db.prepare("SELECT COUNT(*) orders,COALESCE(SUM(CASE WHEN status='Successful' THEN amount END),0) revenue,SUM(status='Successful') paid,SUM(fulfillment='Awaiting fulfillment') awaiting FROM orders").get()));
A.put('/banner',(q,r)=>{db.prepare("INSERT OR REPLACE INTO settings VALUES('banner',?)").run(String(q.body.banner||'').slice(0,200));r.json({ok:1})});
app.use(express.static('public'));
app.use((e,q,r,n)=>{console.error(e);r.status(500).json({error:'Server error'})});
app.listen(PORT,()=>console.log('Gigi Data Hub on '+BASE));
