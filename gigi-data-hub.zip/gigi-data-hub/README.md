# Gigi Data Hub
Node 18+ / Express / SQLite. Frontend is plain HTML/JS in `public/`.

## Run
1. `npm install`
2. `cp .env.example .env`, then fill it in (load with `node --env-file=.env server.js`)
3. Open http://localhost:3000, admin at `/admin.html`

## Database
SQLite file `data.db` is created and seeded with DEMO bundles (GH₵5/10/20/40) and one PLACEHOLDER unverified USSD code on first start. Edit them in the admin. Back up `data.db`.

## Payments (Paystack)
1. Set `PAYSTACK_SECRET_KEY` (use a test key first) and `BASE_URL` (your public https URL).
2. In the Paystack dashboard set the webhook URL to `BASE_URL/api/paystack/webhook`.
3. Orders become Successful only after the server verifies with Paystack (callback and webhook), checking amount and GHS currency. Without a key, checkout returns a demo-mode error and creates no order.
Hubtel: replace `ps()`, `/api/checkout` and `settle()` with Hubtel's API calls, keeping server-side verification.

## Fulfillment
After payment, orders show "Awaiting fulfillment". Admin marks them Delivered manually. To automate, implement `deliver()` in `server.js` with your authorized reseller API (keys in `DELIVERY_*` env vars) and only set Delivered once the provider confirms.

## Production
Host on any Node host (Render, Railway, VPS) behind HTTPS with a persistent disk for `data.db`. Set strong `ADMIN_PASSWORD` and `SESSION_SECRET`. Replace demo legal text, social links and verified USSD codes before launch. Have a lawyer review policies.

## Known limits (lean build)
Single admin role (no multi-user roles yet), in-memory login rate limit, no email receipts, refunds are marked manually after refunding in Paystack.
